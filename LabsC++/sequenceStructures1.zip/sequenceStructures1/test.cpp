// This is a trash file. Pay no attention to it.

#include <iostream>
int main(){
    std::cout << "Hello World!";
    return 0;
}